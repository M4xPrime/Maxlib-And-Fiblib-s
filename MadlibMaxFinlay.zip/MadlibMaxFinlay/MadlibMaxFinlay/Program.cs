﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace Madlib_fibandmax
{
    class Madlib
    {
        public string Creature;
        public string Luminous;
        public string Ghastly;
        public string Spectral;
        public string Countryman;
        public string Farrier;
        public string Farmer;
        public string Dreadful;
        public string Apparition;
        public string Hound;
        public string Story;
        public static void Title()
        {
            // Sets Up Game
            Console.Title = "Madlib | Fiblay and Macks Addition";
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine(@"
                                       _ _ _                           _    __ _ _     _ _ _         
                  _ __ ___   __ ___  _| (_| |__  ___    __ _ _ __   __| |  / _(_| |__ | (_| |__  ___ 
                 | '_ ` _ \ / _` \ \/ | | | '_ \/ __|  / _` | '_ \ / _` | | |_| | '_ \| | | '_ \/ __|
                 | | | | | | (_| |>  <| | | |_) \__ \ | (_| | | | | (_| | |  _| | |_) | | | |_) \__ \
                 |_| |_| |_|\__,_/_/\_|_|_|_.__/|___/  \__,_|_| |_|\__,_| |_| |_|_.__/|_|_|_.__/|___/
                                        Press Any Key For a MAD(libs) time! B^D
");
            Console.ReadLine();
        }
        public void Game()
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.Write("Please enter a noun: ");
            Creature = Console.ReadLine();
            Console.Write("Please enter an adjective: ");
            Luminous = Console.ReadLine();
            Console.Write("Please enter an adjective: ");
            Ghastly = Console.ReadLine();
            Console.Write("Please enter an adjective: ");
            Spectral = Console.ReadLine();
            Console.Write("Please enter an occupation: ");
            Countryman = Console.ReadLine();
            Console.Write("Please enter an occupation: ");
            Farrier = Console.ReadLine();
            Console.Write("Please enter an occupation: ");
            Farmer = Console.ReadLine();
            Console.Write("Please enter an adjective: ");
            Dreadful = Console.ReadLine();
            Console.Write("Please enter a noun: ");
            Apparition = Console.ReadLine();
            Console.Write("Please enter a noun: ");
            Hound = Console.ReadLine();
            //write out story            
            Story = "Once Upon a time " + Creature + ", " + Luminous + ", " + Ghastly + ", and " + Spectral + " are looking for the ultimate weapon!  " + Countryman + "told us they knew where it was. " + Farrier + " said to not trust " + Countryman + ". " + Farmer + " Who told us not to trust anyone. " + Dreadful + " and " + Apparition + " said the exact same thing; I don't trust anyone. " + Hound + " said they knew where it was. And thats when they all knew what to do . . .  [TO BE CONTINUED]";
            Console.WriteLine(Story);
            //keep window open and prompt for exit
            Console.WriteLine("Press enter to exit");
            Console.ReadKey();
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Madlib Game = new Madlib();
            Madlib.Title();
            Game.Game();
        }
    }
}